import React from 'react'

const Sun = () =>
	<div id='sun'>
		<dl className='infos'>
			<dt>Sun</dt>
			<dd><span></span></dd>
		</dl>
	</div>

export default Sun
