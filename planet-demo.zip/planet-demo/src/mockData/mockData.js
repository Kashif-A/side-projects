export const mockData = {
  name: 'Planet', 
  distanceFromSun: 88888, 
  mass: 'Test', 
  diameter: 88888, 
  imageUrl: 'https://ca-times.brightspotcdn.com/dims4/default/f8f354e/2147483647/strip/true/crop/3840x2160+0+0/resize/840x473!/quality/90/?url=https%3A%2F%2Fcalifornia-times-brightspot.s3.amazonaws.com%2F9b%2Fce%2F0fc55afa4cd388c7d9257e6b4b97%2Fgj357-d-360-thm.jpg'
}